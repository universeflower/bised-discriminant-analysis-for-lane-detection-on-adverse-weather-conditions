# lane > 2024-10-19 1:01am
https://universe.roboflow.com/junseok-fx4yo/lane-geznh

Provided by a Roboflow user
License: CC BY 4.0

