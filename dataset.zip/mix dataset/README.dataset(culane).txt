# CULanes > 2024-07-26 10:32am
https://universe.roboflow.com/lanes-qp7qp/culanes-m0cxq

Provided by a Roboflow user
License: CC BY 4.0

